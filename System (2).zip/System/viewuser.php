<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>staffsdetails</title>
<style>
#rcorners1 {
  border-radius: 25px;
  background: #969696;
  padding: 20px; 
  height: 150px;  
}

</style>
</head>

<body id="rcorners1">
<table width="100%" height="100%" border="0">
  
  <tr>
    <td colspan="14"><?php include('sms/menu/sms menu.php'); ?>    </td>
  </tr>
  <tr>
    <td colspan="14" align="center"><strong><font color="#990000"><font size="6">VIEW REGISTERED USERS</font></font> </strong></td>
  </tr>
  <tr>
    <td width="3%">UserID</td>
    <td width="12%">Username</td>
	<td width="12%">Password</td>
	<td width="12%">Contact_No</td>
	<td width="12%">Address</td>
	<td width="12%">FName</td>
	<td width="12%">LNmae</td>
    
    
    <td width="11%" colspan="2">&nbsp;</td>
  </tr>
  <?php
  //connecting to the server
  $con = mysqli_connect("localhost","root","")or die('failed to connect to the server'.mysqli_connect_error());//check for connection to server
$objDB = mysqli_select_db($con,"shop") or die ('failed to select database'.mysqli_connect_error($con));//select db to use

$sel= mysqli_query($con, "select*from user") or die ('failed to select comments details '.mysqli_connect_error($con));
//introduce while loop   for repeated input

while ($row=mysqli_fetch_assoc($sel)){

$uID = $row['UserID'];
$Name = $row['Username'];
$pass = $row['Password'];
$cont = $row['Contact_No'];
$address = $row['Address'];
$fname = $row['FName'];
$lname = $row['LName'];


  
  ?>
  <tr>
    <td><?php echo $uID;?></td>
    <td><?php echo $Name;?></td>
	<td><?php echo $pass;?></td>
	<td><?php echo $cont;?></td>
	<td><?php echo $address;?></td>
	<td><?php echo $fname;?></td>
	<td><?php echo $lname;?></td>
   
    
  </tr>
  <?php
  }
  
  ?>
  <tr>
<td colspan="6"><div align="center"><em><strong><font color="#990000">All rights reserved by brainstartechnologiz @2022 </font></strong></em></div></td>  </tr>
</table>
</body>
</html>
