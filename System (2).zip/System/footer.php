
      <!-- *** FOOTER ***
 _________________________________________________________ -->
        <div id="footer" data-animate="fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <h4><font color="#990000">PAGES</font></h4>

                        <ul>
                            <li><a href="text.html">ABOUT US</a>
                            </li>
                            <li><a href="text.html">Terms and conditions</a>
                            </li>
                            <li><a href="faq.html">FAQ</a>
                            </li>
                            <li><a href="contact.html">Contact us</a>
                            </li>
                        </ul>

                        <hr>

                      

                        <hr class="hidden-md hidden-lg hidden-sm">

                    </div>
                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4><font color="#990000">Contact Us</font></h4>

                        <h5>+256 756 824 119 </h5>
                        <h5>+256 781 557 803 </h5>

                        

                        <hr class="hidden-md hidden-lg">

                    </div>
                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4><font color="#990000">FIND US IN</font>
                            <br>
                            UGANDA
                            <br>
                            Kampala
                            <br>
                            kibuye
                            <br>
                        Salaama Road </h4>

                        <a href="contact.php">Go to contact page</a>

                        <hr class="hidden-md hidden-lg">

                    </div>
                    <!-- /.col-md-3 -->



                    <div class="col-md-3 col-sm-6">

                          <h4><font color="#990000">User section</font></h4>

                        <ul>
                            <li><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
                            </li>
                            <li><a href="register.html">Regiter</a>
                            </li>
                        </ul>

                            </div>
                            <!-- /input-group -->
                        </form>

                        <hr>

                    
                    </div>
                    <!-- /.col-md-3 -->

                </div>
                <!-- /.row -->

            </div>
            <!-- /.container -->
        </div>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->




        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left"><font color="#660000">© All Rights Reserved By Brainstartechnologiz Uganda .....Developed By BAKULUMPAGI RONALD </font></p>
					 <ul>
					
                                    <li><strong><a href="mailto:">bakulumpagironald48@gmail.com</a></strong></li>
                                    
                                    
					 </ul>

                </div>
                
            </div>
        </div>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->
