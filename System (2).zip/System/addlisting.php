

<?php 
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Obaju e-commerce template">
    <meta name="author" content="Ondrej Svestka | ondrejsvestka.cz">
    <meta name="keywords" content="">

    <title>
       My Final Year Project
    </title>

    <meta name="keywords" content="">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

    <!-- styles -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- theme stylesheet -->
    <link href="css/style.default.css" rel="stylesheet" id="theme-stylesheet">

    <!-- your stylesheet with modifications -->
    <link href="css/custom.css" rel="stylesheet">

    <script src="js/respond.min.js"></script>

    <link rel="shortcut icon" href="favicon.png">


    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    
</head>

<body>

   <?php $db = mysqli_connect('localhost','root','','shop')
        or die('Error connecting to MySQL server.'); 

        $query1 = "SELECT * FROM category ";
        $result1 = mysqli_query($db, $query1);
        $categories = mysqli_fetch_array($result1);

    ?>
    <?php include 'header.php';?>

    <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a>
                        </li>
                        <li><font color="#990000">Add Item</font></li>
                    </ul>

                </div>

                <div class="col-md-3">
                    <!-- *** PAGES MENU ***
 _________________________________________________________ -->
                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title"><font color="#990000">Quick Links</font></h3>
                        </div>

                        <div class="panel-body">
                            <ul class="nav nav-pills nav-stacked">
                                <li>
                                    <a href="index.php">Home</a>
                                </li>
                                <li>
                                    <a href="contact.php">Contact Us</a>
                                </li>
                                <li>
                                    <a href="faq.php">FAQ</a>
                                </li>

                            </ul>

                        </div>
                    </div>

                    <!-- *** PAGES MENU END *** -->


                    <div class="banner">
                        <a href="#">
                            <img src="img/construction-bidding.jpg" alt="sales 2014" width="400" class="img-responsive">                        </a>                    </div>
                </div>

                <div class="col-md-9">
				
				
				
				
				
				
<?php 
                                $query1 = "SELECT * FROM category ";
                                $result1 = mysqli_query($db, $query1);
                                $categories = mysqli_fetch_array($result1);

                            ?>

                    <div class="box" id="contact">
                        <h1><font color="#990000">Add a new listing</font></h1>

                        <p class="lead">Do you want to sell something? Get the best price for it through our auction system ! </p>
                        

                        <hr>

                        <?php
                        if(isset($_GET['err'])) {
                            echo '
                                    <div class="alert alert-info">
                                         <strong>Sorry!</strong> You need to <a href="register.php">log in</a> to add a listing.
                                    </div>
                                    ';
                        }
                        ?>
                        <div class="panel-group" id="accordion">
                        

                        <form class="form-horizontal" action="success.php" method="POST">

                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h4 class="panel-title">

					    <a data-toggle="collapse" data-parent="#accordion" href="#faq1">

						<font color="#990000">1. What to do you want to sell?</font>

					    </a>

					</h4>
                                </div>
                                <div id="faq1" class="panel-collapse collapse">
                                    <div class="panel-body">
                                    <div class="form-group">

                                    <label class="control-label col-sm-2" for="pwd">Category :</label>
                                        <div class="col-sm-10">
                                       
                                              <select class="form-control" name="CategoryID">
                                               <?php
                                                $value=1;
                                                 while($categories) { 
                
                                                   ?>
                                                <option value="<?php echo $value ?>"> <?php echo $categories["Category"];?></option>
                                                <?php $categories = $result1->fetch_assoc();
                                                    $value=$value+1;
                                                }?>
                                              </select>
                                              <br>
                                             </div>       
                                            <br>       
                                                    
                                        <label class="control-label col-sm-2" >Item Name:</label>
                                          <div class="col-sm-10">
                                            <input type="text" class="form-control" name="ItemName" placeholder="Enter the listing name">
                                          </div>       
                                          </div>   

                                                                          
                                    </div>
                                </div>
                            </div>
                          
                            <!-- /.panel -->

                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h4 class="panel-title">

					    <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">

						<font color="#990000">2. Tell more about your product.</font>

					    </a>

					</h4>
                                </div>

                                <div id="collapseTwo" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <label class="control-label col-sm-2" >Description:</label>
                                         <div class="col-sm-10">
                                        <textarea class="form-control" rows="5" name="Description"></textarea>
                                        <br>
                                        </div>
                                    
                                    <label class="control-label col-sm-2" >Images :</label>
                                         <div class="col-sm-10">
                                       <input type="text" class="form-control" name="PhotosID" placeholder="Enter the image URL Eg: img/image.jpg">
                                       <br>
                                        </div>


                                        </div>
                                </div>
                            </div>
                            <!-- /.panel -->


                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h4 class="panel-title">

					    <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">

						<font color="#990000">3. Prices and Time period</font>

					    </a>

					</h4>
                                </div>
                                <div id="collapseThree" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <label class="control-label col-sm-2" >Starting Price:</label>
                                         <div class="col-sm-10">
                                       <input type="text" class="form-control" name="StartingPrice" placeholder="Enter the Starting Value in ugandan shillings">
                                       <br>
                                        </div>

                                       <label class="control-label col-sm-2" for="comment">Expected Price:</label>
                                        <div class="col-sm-10">
                                       <input type="text" class="form-control" name="ExpectedPrice" placeholder="Enter the Expected Value in ugandan shillings">
                                       <br>
                                        </div>

                                        <label class="control-label col-sm-2" for="comment">End Date:</label>
                                        <div class="col-sm-10">
                                       <div class="container" >
                                        
                                        <div class="container">
                                            <input required value="<?php echo date('Y-m-d'); ?>" class="date-picker" type="text" id="datepicker" name="EndTime">

                                        </div>
                                        </div>

                                    </div>

                                </div>

                            </div>

                            <!-- /.panel -->

                        </div>
                        <br>
                        
                         <input type="submit" name="Add" align ="left" class="btn btn-primary center-block" type="submit" value="Submit Listing">
                       
                        <!-- /.panel-group -->
                    
					
					<?php
if (isset($_REQUEST['Add']))
{ 
$con = mysqli_connect("localhost","root","")or die('failed to connect to the server'.mysqli_connect_error());//check for connection to server
$objDB = mysqli_select_db($con,"shop") or die ('failed to select database'.mysqli_connect_error($con));//select db to use

//capture info from the form

$img = $_POST['image'];
$name = $_POST['NAME'];
$Cat = $_POST['category'];
$Buyingprice = $_POST['buyingprice'];
$StartBIDPrice = $_POST['startbidprice'];
$spllr = $_POST['supplier'];
$loc = $_POST['location'];
$start = $_POST['Date3'];
$end = $_POST['Date2'];
$date = $_POST['Date'];

$rate= $_POST['Rate'];

$sql = mysqli_query($con,"INSERT INTO productstable(images,name,category,bprice,startprice,supplier,Location,Start_Time,End Time,date,rate)

VALUES
('$img','$name','$Cat','$Buyingprice','$StartBIDPrice','$spllr','$loc','$start','$end','$date','$rate')")
or

die('failed to insert data to db try again'.mysqli_error($con));

if($sql)//if the record is successfuly inserted
{

$st = $name."  has been inserted";
echo $st;
}//closing bracket for  if the record is successfully recorded


}
?>

					
					
					
					
					</form>

                    </div>


                </div>
                <!-- /.col-md-9 -->
            </div>
            <!-- /.container -->
        </div>
        <!-- *** FOOTER ***
 _________________________________________________________ -->
      
    <?php include 'footer.php';?>
    <!-- /#all -->


    

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>
    <script src="js/bootstrap.js"></script>



    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

    <script>
        $(function() {
            $( "#datepicker" ).datepicker({
                dateFormat: "yy-mm-dd"
            });
        });
    </script>
    
        
</body>

</html>
