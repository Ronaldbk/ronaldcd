<?php

$prdID = $_GET['sty'];
$con = mysqli_connect("localhost","root","")or die('failed to connect to the server'.mysqli_connect_error());//check for connection to server


$objDB = mysqli_select_db($con,"shop") or die ('failed to select database'.mysqli_connect_error($con));

//pick data frm mysql

$sel= mysqli_query($con, "select*from item where ItemID ='$prdID'") or die ('failed to select staff details '.mysqli_connect_error($con));
//introduce while loop   for repeated input

while ($row=mysqli_fetch_assoc($sel))
{



$iid = $row['ItemID'];
$itemname = $row['ItemName'];
$sid = $row['SellerID'];
$sp = $row['StartingPrice'];
$ep = $row['ExpectedPrice'];
$cp = $row['CurrentPrice'];
$pid= $row['PhotosID'];
$des= $row['Description'];
$endtime = $row['EndTime'];
$category = $row['Category'];
}


?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>edit products page</title>
</head>

<body>
<form method="post" action="" name="product">
<table width="100%" height="100%" border="0">
  <tr>
    <th colspan="6" scope="col"> <?php include('sms/menu/sms menu.php'); ?> </th>
  </tr>
  <tr>
    <td colspan="6">&nbsp;</td>
  </tr>
  <tr>
    
    <td width="17%">&nbsp;</td>
    <td></td>
    <td width="16%" colspan="2" rowspan="13">&nbsp;</td>
    </tr>
  <tr>
    <td height="33">&nbsp;</td>
    <td height="33">ItemID</td>
    <td colspan="2"> <input type="text" name="iid" id="nm" value="<?php echo $id ?>" /></td>
    </tr>
  <tr>
    <td height="27">&nbsp;</td>
    <td height="27">Item Name </td>
    <td colspan="2"> <input type="text" name="itemname" id="cat" value="<?php echo $in ?>" /></td>
    </tr>
  <tr>
    <td height="26">&nbsp;</td>
    <td height="26">SellerID</td>
    <td colspan="2"> <input type="currency" name="sellerid" id="price1" value="<?php echo $sid ?>" /></td>
    </tr>
  <tr>
    <td height="24">&nbsp;</td>
    <td height="24">Starting Price </td>
    <td colspan="2"> <input type="currency" name="startingprice" id="price2" value="<?php echo $sp ?>" /></td>
    </tr>
  <tr>
    <td height="39">&nbsp;</td>
    <td height="39">Expected Price </td>
    <td colspan="2"> <input type="text" name="expectedprice"  id="supplier1" value="<?php echo $ep ?>"/></td>
    </tr>
  <tr>
    <td height="32">&nbsp;</td>
    <td height="32">Current Price </td>
    <td colspan="2"> <input type="Date" name="currentprice" id="date1" value="<?php echo $cp ?>"/></td>
    </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td height="40">PhotosID</td>
    <td colspan="2"><input type="text" name="photosid" id="Rate" value="<?php echo $pid ?>"/></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td height="40">Description</td>
    <td colspan="2"><input type="text" name="description" id="description" value="<?php echo $des ?>"/></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td height="40">End Time </td>
    <td colspan="2"><input type="text" name="EndTime" id="description2" value="<?php echo $endtime ?>"/></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td height="40">Category</td>
    <td colspan="2"><input type="text" name="Category" id="rating" value="<?php echo $category ?>"/></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="14%"><strong>
      <label>      </label>
    </strong>
      <label></label>
      <strong>
      <label><input name="cancel" type="reset" value="CANCAL" onclick="return confirm('are you sure to cancel?')" />   </label>
      </strong></td>
    <td width="37%"><input type="submit" name="Add" value="SAVE" /></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    </tr>
  <tr>
<td colspan="6"><div align="center"><em><strong>All rights reserved by SMS @2022 </strong></em></div></td>  </tr>
</table>

<?php
if (isset($_REQUEST['Add']))
{ 
$con = mysqli_connect("localhost","root","")or die('failed to connect to the server'.mysqli_connect_error());//check for connection to server
$objDB = mysqli_select_db($con,"shop") or die ('failed to select database'.mysqli_connect_error($con));//select db to use

//capture info from the form

$id = $_POST['iid'];
$in= $_POST['itemname'];
$sid = $_POST['sellerid'];
$sp = $_POST['startingprice'];
$ep= $_POST['expectedprice'];
$cp = $_POST['currentprice'];
$pid= $_POST['photosid'];
$des= $_POST['description'];
$endtime= $_POST['EndTime'];
$category= $_POST['Category'];

$sql = mysqli_query($con,"UPDATE item   
 SET ItemID='$id',ItemName='$in',SellerID='$sid',StartingPrice='$sp',ExpectedPrice='$ep',CurrentPrice='$cp',PhotosID='$pid',Description='$des',EndTime='$endtime',Category='$category'

WHERE ItemID='$prdID'") or die('failed to update data:'.mysqli_error($con));

if($sql)//if the record is successfuly inserted
{

$st = $name." has been updated";
echo $st;
}//closing bracket for  if the record is successfully recorded


}
?>


</form>
</body>
</html>
