<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>staffsdetails</title>
<style>
#rcorners1 {
  border-radius: 25px;
  background: #969696;
  padding: 20px; 
  height: 150px;  
}

</style>
</head>

<body id="rcorners1">
<table width="100%" height="100%" border="0">
  <tr>
    <td colspan="14"><img src="img/view-items.png" width="100%" height="300" /></td>
  </tr>
  <tr>
    <td colspan="14"><?php include('sms/menu/sms menu.php'); ?>    </td>
  </tr>
  <tr>
    <td colspan="14" align="center"><strong>products page </strong></td>
  </tr>
  <tr>
    <td width="3%">ItemID</td>
    <td width="12%">ItemName</td>
    <td width="11%">SellerID</td>
    <td width="7%">StartingPice</td>
    <td width="10%">ExpectedPrice </td>
    <td width="9%">CurrentPrice</td>
    <td width="7%">PhotosID</td>
	<td width="7%">Description</td>
	 <td>EndTime</td>
    <td width="12%">CategoryID</td>
   
    <td colspan="2"><div align="center">Action</div></td>
    <td width="11%" colspan="2">&nbsp;</td>
  </tr>
  <?php
  //connecting to the server
  $con = mysqli_connect("localhost","root","")or die('failed to connect to the server'.mysqli_connect_error());//check for connection to server
$objDB = mysqli_select_db($con,"shop") or die ('failed to select database'.mysqli_connect_error($con));//select db to use

$sel= mysqli_query($con, "select*from item") or die ('failed to select staff details '.mysqli_connect_error($con));
//introduce while loop   for repeated input

while ($row=mysqli_fetch_assoc($sel)){

$iID = $row['ItemID'];
$itname = $row['ItemName'];
$sid = $row['SellerID'];
$sp = $row['StartingPrice'];
$ep = $row['ExpectedPrice'];
$cp= $row['CurrentPrice'];
$pid= $row['PhotosID'];
$des=$row['Description'];
$endtime = $row['EndTime'];
$category = $row['CategoryID'];
  
  ?>
  <tr>
    <td><?php echo $iID;?></td>
     <td><?php echo $itname;?></td>
    <td><?php echo $sid;?></td>
    <td><?php echo $sp;?></td>
    <td><?php echo $ep;?></td>
    <td><?php echo $cp;?></td>
	<td><?php echo $pid;?></td>
    <td><?php echo $des;?></td>
    <td><?php echo $endtime;?></td>
	<td><?php echo $category;?></td>
    <td width="8%" ><a href ="editproducts.php?sty=<?php echo $ItemID;?>">Edit </a></td>
    <td width="4%" ><a href ="delete page.php?sty=<?php echo $ItemID;?>">Delete</a></td>
  </tr>
  <?php
  }
  
  ?>
  <tr>
    <td colspan="13"><div align="center"><em><strong>All rights reserved by SMS @2022 </strong></em></div></td>
  </tr>
</table>
</body>
</html>
