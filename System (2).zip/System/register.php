<?php 
session_start(); 

if(isset($_SESSION['userid'])){
    header('Location: index.php');
}   

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Obaju e-commerce template">
    <meta name="author" content="Ondrej Svestka | ondrejsvestka.cz">
    <meta name="keywords" content="">

    <title>
        Obaju : e-commerce template
    </title>

    <meta name="keywords" content="">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

    <!-- styles -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">

    <!-- theme stylesheet -->
    <link href="css/style.default.css" rel="stylesheet" id="theme-stylesheet">

    <!-- your stylesheet with modifications -->
    <link href="css/custom.css" rel="stylesheet">

    <script src="js/respond.min.js"></script>

    <link rel="shortcut icon" href="favicon.png">



</head>

<body>

    <?php include 'header.php';?>


    <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">

                    <ul class="breadcrumb">
                        <li><a href="#">Home</a>
                        </li>
                        <li><font color="#990000">New account / Sign in</font></li>
                    </ul>

                </div>

                <div class="col-md-6">
                    <div class="box">
                        <h1><font color="#990000">New account</font></h1>

                        <p class="lead">Not our registered customer yet?</p>
                        <hr>
                        <?php
                        if(isset($_GET['err']) && $_GET['err'] == 2) {
                            echo '
                            <div class="alert alert-danger">
                                <strong>Error!</strong> Username you entered already exists.
                            </div>
                            ';
                        }

                        if(isset($_GET['success'])) {
                            echo '
                            <div class="alert alert-success">
                                <strong>Success!</strong> Your account was successfully created. Please log in to continue.
                            </div>
                            ';
                        }
                        ?>

                        <form action="process_register.php" method="post">
                            <div class="form-group">
                                <label for="fname">First Name</label>
                                <input type="text" class="form-control" id="fname" name="fname">
                            </div>
                            <div class="form-group">
                                <label for="lname">Last Name</label>
                                <input type="text" class="form-control" id="lname" name="lname">
                            </div>
                            <div class="form-group">
                                <label for="addr">Address</label>
                                <input type="text" class="form-control" id="addr" name="addr">
                            </div>
                            <div class="form-group">
                                <label for="cno">Contact Number</label>
                                <input type="text" class="form-control" id="cno" name="cno">
                            </div>
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password">
                            </div>
                            <div class="text-center">
                                <button type="submit" name="register" class="btn btn-primary"><i class="fa fa-user-md"></i> Register</button>
                            </div>
                        </form>

                        
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="box">
                        <h1><font color="#990000">Login</font></h1>

                        <p class="lead"><font color="#990000">Already our customer Sigh in?</font></p>
                        <hr>

                        <?php 
                        if(isset($_GET['err']) && $_GET['err'] == 1) {
                            echo '
                            <div class="alert alert-danger">
                                <strong>Error!</strong> You have entered an invalid username or password.
                            </div>
                            ';
                        }
                        ?>
                        <form action="process_login.php" method="post">
                            <div class="form-group">
                                <label for="email">Username</label>
                                <input type="text" class="form-control" id="email" name="username">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password">
                            </div>
                            <div class="text-center">
                                <button type="submit" name="cmdlogin" class="btn btn-primary"><i class="fa fa-sign-in"></i> Log in</button>
                            </div>
                        </form>
                    </div>
                </div>


            </div>
            <!-- /.container -->
        </div>
        <!-- /#content -->


        
    <?php include 'footer.php';?>

    

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>



</body>

</html>
