<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>admin page</title>
<style>
.button {
  background-color: #006666;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 4px;
  cursor: pointer;
}

#rcorners1 {
  border-radius: 25px;
  background: #969696;
  padding: 20px; 
  width: ;
  height: 150px;  
}

.tooltip {
  position: relative;
  display: inline-block;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;
  position: absolute;
  z-index: 1;
  bottom: 150%;
  left: 50%;
  margin-left: -60px;
}

.tooltip .tooltiptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #006633;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
}

</style>
</head>

<body id="rcorners1"> 


<table width="100%" height="100%" border="0" bgcolor="#FFFFFF">
  <tr>
    <th colspan="6" scope="col" background="img/118-1185804_campus-management-system-medical-store-billing-pos-campus-management-system-medical-store.png"><span class="tooltip"><font color="#990000"><font size="20">WELCOME  ADMINISTRATOR</font></font></span>    <?php include('sms/menu/sms menu.php'); ?></th>
  </tr>
  <tr>
    <td width="23%">&nbsp;</td>

    <td colspan="4"><img src="img/Bidding-process.jpg" width="100%" height="300" /></td>
    <td width="12%">&nbsp;</td>
  <tr> 
 <td width="23%"><a href="products details.php" class="button" > 
   <div class="tooltip">PRODUCTS<span class="tooltiptext">CLICK HERE</span></div></a> </td>
	
	  <td width="26%"><a href="viewcategories.php" class="button"><span class="tooltip">VIEW CATEGORIES <span class="tooltiptext">CLICK </span></span></a></td>
	    <td width="22%"><a href="additem2.php" class="button">
    <div class="tooltip">REGISTER PRODUCTS<span class="tooltiptext">CLICK HERE</span></div></a></td>
		  <td width="7%"> </td>
    <td width="10%"><a href="viewuser.php" class="button">
    <div class="tooltip">CUSTOMMERS<span class="tooltiptext">CLICK HERE</span></div></a></td>
    
  </tr>
  <tr>
    <th height="51" colspan="2" scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
<td colspan="6"><div align="center"><em><strong><font color="#990000">All rights reserved by brainstartechnologiz @2022 </font></strong></em></div></td>  </tr>
</table>
</body>
</html>
