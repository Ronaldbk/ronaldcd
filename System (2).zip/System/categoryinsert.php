<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>products page</title>
<style>
#rcorners1 {
  border-radius: 25px;
  background: #969696;
  padding: 20px; 
  width: ;
  height: 150px;  
}

</style>
</head>

<body id="rcorners1">
<form method="post" action="" name="product1">
<table width="100%" height="100%" border="0">
  <tr>
    <th colspan="6" scope="col"><?php include('sms/menu/sms menu.php'); ?> </th>
  </tr>
  <tr>
    <th colspan="6" scope="col"><font color="#990000"><font size="6">ENTER CATEGORIES </font></font></th>
  </tr>
  <tr>
    <td colspan="6">&nbsp;</td>
  </tr>
  <tr>
    <td width="16%" height="32">&nbsp;</td>
    <td width="17%">Category ID </td>
    <td colspan="2"><input type="text" name="categoryid"  id="supplier4" placeholder="item id"/></td>
    <td width="16%" colspan="2" rowspan="12">&nbsp;</td>
    </tr>
  <tr>
    <td height="33">&nbsp;</td>
    <td height="33">CategoryName</td>
    <td colspan="2"> <input type="text" name="cNAME" id="nm" placeholder="ITEM Name" /></td>
    </tr>
  
    <td colspan="2">&nbsp;</td>
    <td width="14%"><strong>
      <label>      </label>
    </strong>
      <label></label>
      <strong>
      <label><input name="cancel" type="reset" value="CANCAL" onclick="return confirm('are you sure to cancel?')" />   </label>
      </strong></td>
    <td width="37%"><input type="submit" name="Add" value="SAVE"/></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    </tr>
  <tr>
<td colspan="6"><div align="center"><em><strong><font color="#990000">All rights reserved by brainstartechnologiz @2022 </font></strong></em></div></td>  </tr>
</table>

<?php
if (isset($_REQUEST['Add']))
{ 
$con = mysqli_connect("localhost","root","")or die('failed to connect to the server'.mysqli_connect_error());//check for connection to server
$objDB = mysqli_select_db($con,"shop") or die ('failed to select database'.mysqli_connect_error($con));//select db to use

//capture info from the form

$cid = $_POST['categoryid'];
$cname = $_POST['cNAME'];

$sql = mysqli_query($con,"INSERT INTO category(CategoryID,Category)VALUES('$cid','$cname')")
or

die('failed to insert data to db try again'.mysqli_error($con));

if($sql)//if the record is successfuly inserted
{

$st = $cname."  has been inserted";
echo $st;
}//closing bracket for  if the record is successfully recorded


}
?>


</form>
</body>
</html>
