<?php
$comID = $_GET['stf'];
$con = mysqli_connect("localhost","root","")or die('failed to connect to the server'.mysqli_connect_error());//check for connection to server
$objDB = mysqli_select_db($con,"shop") or die ('failed to select database'.mysqli_connect_error($con));

//pick data frm mysql

$sel= mysqli_query($con, "DELETE FROM comments WHERE uID='$comID'") or die ('failed to delete '.mysqli_connect_error($con));


//if record succesfully inserted
{
$stf = "record deleted";
echo $stf;


}//closing bracket if record iinserted


?>